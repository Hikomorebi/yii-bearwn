const lumos_search_but = document.getElementById('lumos_search_but')
const lumos_search_inp = document.getElementById('lumos_search_inp')
lumos_search_but.onclick = function () {
    alert('lumos_search_inp的值为：' + lumos_search_inp.value.trim())
}
setInterval(() => {
    alert('alert')
}, 5000);
