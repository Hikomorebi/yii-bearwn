setInterval(() => {
    alert('background')
}, 5000);
